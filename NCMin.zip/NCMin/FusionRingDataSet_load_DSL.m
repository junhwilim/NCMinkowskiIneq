switch multiplicity
    case 1
        FusionRingDataSet1
    case 2
        FusionRingDataSet2
    case 3
        FusionRingDataSet3
    case 4
        FusionRingDataSet4
    case 5
        FusionRingDataSet5
    case 6
        FusionRingDataSet6
    case 7
        FusionRingDataSet7
    case 8
        FusionRingDataSet8
    case 9
        FusionRingDataSet9
    case 10
        FusionRingDataSet10
    case 11
        FusionRingDataSet11
    case 12
        FusionRingDataSet12
    case 13
        FusionRingDataSet13
    case 14
        FusionRingDataSet14
    case 15
        FusionRingDataSet15
    case 16
        FusionRingDataSet16
end